# Mockup1
A first draft mockup for a new SuperCamp "Our-Team" page. 
The page will focus on a new shift towards exhibiting staff personality
as well as credentials.
